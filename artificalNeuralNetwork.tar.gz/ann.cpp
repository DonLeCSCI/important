#include "ann.h"
#include<vector>
#include<iostream>
#include<list>
#include<math.h>
#include<iomanip>

using namespace std;


void Net::inFunction(vector<vector<Node>> &layer, vector<int> & struc)
{
  long double iterVal;
  for(int i = 1; i < struc.size(); i++) //each layer
  {
    for(int j = 0; j < struc[i]; j++) //for each node
    {
      long double in = 0;
      for(int k = 0; k < struc[i-1]; k++) //for each prev layer
      {
        in += layer[i-1][k].weight[j] * layer[i-1][k].a;
      }
      iterVal = layer[i][j].initialW + in;
      long double inver = iterVal/-1;
      long double x = 1 + exp(inver);
      long double answer = 1/x;
      layer[i][j].a = answer;
    }
  }
}

void Net::delta(vector<vector<Node>> &layer, vector<int> &struc, vector<vector<double>> &encode,vector<int> &trainOut, int &k)
{
  for(int i = struc.size()-1; i > struc.size()-2; i--) //output layer
  {
    long double delta;
    for(int j = 0; j < struc[i]; j++) // for each node in output layer
    {
      int x = trainOut[k-1];
      double y = encode[x][j];
      long double a = layer[i][j].a;
      delta = a * (1-a) * (y - a);
      layer[i][j].d = delta;
//      cout << "network" << "[" << i << "]" << "[" << j << "]" << ".delta" << " " << "="  << " " << showpoint << fixed << setprecision(12) << delta << endl;
    }
  }
}


void Net::deltaInner(vector<vector<Node>> &layer, vector<int> &struc)
{
  long double delta2 = 0;
  for(int i = struc.size()-2; i > 0; i--) // for each input layer
  {
    for(int j = 0; j < struc[i]; j++) //for each node in input layer
    {
      long double b = layer[i][j].a;
      long double w = 0;
      for(int k = 0; k < struc[i+1];k++) 
      {
        // cout << "i:" << i << " j:" << j << " k:" << k << endl;
        // cout << "weight:" << layer[i][j].weight[k] << endl;
        // cout << "a:" << layer[i+1][k].d << endl;
        w += layer[i][j].weight[k] * layer[i+1][k].d;
      }
      long double zz = b * (1 - b) ;
      delta2 = zz * w;
      layer[i][j].d = delta2;
//      cout << delta2 << endl;
    }
  }
}

void Net::weightSet(vector<vector<Node>> &layer, vector<int> &struc, double &alpha)
{
  for(int i = 0; i < struc.size()-1; i++) //for each layer
  {
    for(int j = 0; j < struc[i]; j++) //for each node in layer
    {
      long double b = layer[i][j].a;
      for(int k = 0; k < struc[i+1]; k++) //index of weights
      {
        layer[i][j].weight[k] = layer[i][j].weight[k] + (alpha * b * layer[i+1][k].d);
      }
    }
  }
} 

void Net::initialSet(vector<vector<Node>> &layer, vector<int> &struc, double &alpha)
{
  for(int i = 1; i < struc.size();i++)
  {
    for(int j = 0; j < struc[i]; j++)
    {
      layer[i][j].initialW = layer[i][j].initialW + (alpha * 1 * layer[i][j].d);
    }
  }
}

long double Net::euclidianDistance(vector<double> &encode, vector<vector<Node>> &layer, vector<int> &struc)
{
  vector<long double> aVals;
  vector<long double> encodeVal;
  for(int i = 0; i < struc[struc.size()-1]; i++) // for each node in output layer
  {
    long double a = layer[struc.size()-1][i].a;
    aVals.push_back(a);
  }

  long double inner = 0.0;

  for(int j = 0; j < aVals.size(); j++)
  {
    inner += pow(encode[j] - aVals[j],2);
  }

  long double d = sqrt(inner); 
 // cout << d << endl;
}


