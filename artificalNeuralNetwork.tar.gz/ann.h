#ifndef ANN_H
#define ANN_H
#include<cstdlib>
#include<vector>
using namespace std;
struct Node{
  double a;
  double d;
  vector<double> weight;
  double initialW = 0.01;
};

class Net{
  public:
    void inFunction(vector<vector<Node>> &layer, vector<int> &struc);
    void delta(vector<vector<Node>> &layer, vector<int> &struc, vector<vector<double>> &encode, vector<int> &trainOutput, int &k);
    void deltaInner(vector<vector<Node>> &layer, vector<int> &struc);
    void weightSet(vector<vector<Node>> &layer, vector<int> &struc, double &alpha);
    void initialSet(vector<vector<Node>> &layer, vector<int> &struc, double &alpha);
    long double euclidianDistance(vector<double> &encode, vector<vector<Node>> &layer, vector<int> &struc);
  private:

};
#endif
