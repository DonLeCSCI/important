#include<iostream>
#include"ann.h" 
#include <iomanip>
#include<list>
#include<vector>
#include <fstream>
#include <sstream>
using namespace std;

int main(int argc, char* argv[])
{


  double alpha = stod(argv[8]);
  int k = stoi(argv[9]);

  // read in train output file
  string input2 = argv[2];
  ifstream myReadFile2;
  myReadFile2.open(input2);
  string line2;
  int val2;
  vector<int> trainOutput;
  while(getline(myReadFile2,line2))
  {
    istringstream str(line2);
    while(str >> val2)
    {
      trainOutput.push_back(val2);
    }
  }

/*
  string input3 = argv[3];
  ifstream myReadFile3;
  myReadFile3.open(input3);
  string line3;
  double val3;
  vector<vector<double>> train;
  while(getline(myReadFile3,line3))
  {
    vector<double> row;
    istringstream str(line3);
    while(str >> val3)
    {
      row.push_back(val3); 
    }
  train.push_back(row);
  }
  */


  //read in encoding file
  string input7 = argv[7];
  ifstream myReadFile7;
  myReadFile7.open(input7);
  string line7;
  double val7;
  vector<vector<double>> encode;
  while(getline(myReadFile7,line7))
  {
    vector<double> row;
    istringstream str(line7);
    while(str >> val7)
    {
      row.push_back(val7); 
    }
    encode.push_back(row);
  }

  int numClass;
  vector<int> classi;
  string input4 = argv[4];
  ifstream myReadFile4;
  myReadFile4.open(input4);
  myReadFile4 >> numClass;
  while(!myReadFile4.eof())
  {
    classi.push_back(numClass);
    myReadFile4 >> numClass;
  }

  //read in structure 
  int numL;
  vector<int> struc;
  string input5 = argv[5];
  ifstream myReadFile5;
  myReadFile5.open(input5);
  myReadFile5 >> numL;
  while(!myReadFile5.eof())
  {
    struc.push_back(numL);
    myReadFile5 >> numL;
  }

  //create a vector vector with a certain amount of nodes
  vector<vector<Node>> network;

  int node;
  for(int k = 0; k < (int)struc.size(); k++)
  {
    node = struc[k];
    vector<Node> v(node);
    network.push_back(v);
  }

  //read in weights
  long double a;
  string line6;
  string input6 = argv[6];
  ifstream myReadFile6;
  myReadFile6.open(input6);
  for(int i = 0; i < (int)struc.size();i++)
  {
    for(int j = 0; j < struc[i]; j++)
    {
      getline(myReadFile6,line6);
      istringstream str(line6);
      while(str >> a)
      {
        network[i][j].weight.push_back(a);
      }
    }
  }

  Net n;
  //read in input file
  for(int t = 0; t < k; t++)
  {
    cout << "TTTTTTTTTTTTT:" << " " << t << endl;
    string input1 = argv[1];
    ifstream myReadFile;
    myReadFile.open(input1);
    string line;
    int row;
    long double val;
    int zz= 0;
    while(getline(myReadFile,line))
    {
      zz++;
      istringstream str(line);

      //for each line in input file store a values at each location in first layer
      for(int j = 0; j < struc[0]; j++)
      {
        str >> val;
        cout << "VALLLLLLLLLLLLLLL:" << " " << val << endl;
        network[0][j].a = val; 
      }

      //find in values of inner layers      
      n.inFunction(network,struc);
      //back propagate and find delta values
      n.delta(network,struc,encode,trainOutput,zz);

      for(int j = 0; j < network.size(); j++)
      {
        for(int i = 0; i < network[j].size();i++)
        {
          cout << "network[" << i << "][" << j << "].a" << " " << "=" << " " << network[j][i].a << endl;
        }
      }


      n.deltaInner(network,struc);
      n.weightSet(network,struc,alpha);

      for(int i = 0; i < struc.size(); i++)
      {
        for(int j = 0; j < struc[i]; j++)
        {
          for(int k = 0; k < network[i][j].weight.size(); k++)
          {
            cout << "weight from layer" << i << "node" << j << "to node:" << k << " " <<  "=" << " " << network[i][j].weight[k] << endl;
          }
        }
      }

      n.initialSet(network,struc,alpha);

      for(int i = 1; i < struc.size(); i++)
      {
        for(int j = 0; j < struc[i]; j++)
        {
          cout << "layer=" << " " << i  << ","  << " " << "w0 of node:" << " " << j << " " << "is" << " " << "=" << " " << network[i][j].initialW << endl;
        }
      }
    }
    myReadFile.clear();
    myReadFile.close();
  }
cout << "end of Learning " << endl;

      for(int k = 0; k < struc[0]; k++)
          {
          cout << showpoint << fixed << setprecision(12) << network[0][0].weight[k] << " ";
          }
      cout << endl;


    string input3 = argv[3];
    ifstream myReadFile3;
    myReadFile3.open(input3);
    string line3;
    int row;
    long double val;
    int zz= 0;

    while(getline(myReadFile3,line3))
    {
      istringstream str(line3);

      //for each line in input file store a values at each location in first layer
      for(int j = 0; j < struc[0]; j++)
      {
        str >> val;
        cout << "VALLLLLLLLLLLLLLL:" << " " << val << endl;
        network[0][j].a = val; 
      }

      //find in values of inner layers      
      n.inFunction(network,struc);

      for(int i = 0; i < network.size(); i++)
      {
        for(int j = 0; j < network[i].size(); j++)
        {
          cout << "network[i][j].a" << " " << "=" << " " << network[i][j].a << endl;
        }
      }

      vector<long double> distances = n.euclidianDistance(encode,classi,network,struc);
      for(int i = 0; i < distances.size(); i++)
      {
      cout << "distance" << " " << distances[i] << endl;
      }
    }
  return 0;
}


