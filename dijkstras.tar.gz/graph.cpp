#include "graph.h"
#include <iostream>
#include <sstream>
#include <climits>
#include <queue>
#include <map>

/*
 @brief: Vertex class constructor within the Graph class
 @param: a string named pi and a integer named key
*/
Graph::Vertex::Vertex(string pi, int key)
{
  this->pi = pi;
  this->key = key;
}

/*
 @brief: Vertex class constructor within the Graph class
 @param: none
*/
Graph::Vertex::Vertex() {
  pi = "";
  key = INT_MAX;
}

/*
 @brief: Neigh class constructor within the Graph class
 @param: none
*/
Graph::Neighbor::Neighbor(string name, int weight)
{
  this->name = name;
  this->weight = weight;
}

/*
 @brief: Takes value and insert vertex into graph
 @param: a string named name
*/
void Graph::addVertex(string name)
{
  Vertex newVert;
  vertices[name] = newVert;
}

/*
 @brief: Takes values and inserts those values into the graph
 @param: a string named from, string named to and an integer named weight
*/
void Graph::addEdge(string from,string to,int weight)
{
  Neighbor tempNeighbor;
  tempNeighbor.name = to;
  tempNeighbor.weight = weight;
  adjList[from].push_back(tempNeighbor);
}

/*
 @brief: will find the shortest paths between the two given values
 @param: a string named from and a string named to
*/
string Graph::getShortestPath(string from,string to)
{

  std::stringstream sStream;
  if(from != currentSource)
  {
    buildSSPTree(from);
    currentSource = from;
  }
  string cur = to;
  std::vector<string> shortestWay;
  while(cur!=from)
  {
    shortestWay.push_back(cur);
    cur = vertices[cur].pi;
  }
  shortestWay.push_back(from);
  for(int i = shortestWay.size() - 1; i > 0; i--)
  {
    sStream << shortestWay[i] << "->"; 
  }
  sStream << to << " "<< "with length" << " " << vertices[to].key;
  std::cout << sStream.str() << std::endl;
  return sStream.str();
}

/*
 @brief: will go through vertices insert values into the queue and then calls
        relax to update the distance to a node
 @param: a string named source
*/
void Graph::buildSSPTree(string source)
{
  initializeSingleSource(source);
  std::map<string, Vertex>::iterator it;
  for(auto it = vertices.begin(); it != vertices.end(); it++)
  {
    minQ.insert(it->first, it->second.key);
  }
  while(!minQ.empty()) 
  {
    string u = minQ.extractMin();
    for(auto itAdj = adjList[u].begin(); itAdj != adjList[u].end(); itAdj++)
    {
      relax(u,itAdj->name,itAdj->weight);
    }
  }
}

/*
 @brief: will update the distance to a node with its minimum value 
 @param: a string named u, a string named v and an integer named weight
*/
void Graph::relax(string u,string v,int weight)
{
  if(vertices[v].key > (vertices[u].key + weight))
  {
    vertices[v].key = (vertices[u].key + weight);
    vertices[v].pi = u; 
    minQ.decreaseKey(v,vertices[v].key);
  }
}

/*
 @brief: will initialize the values of the source
 @param: a string named source
*/
void Graph::initializeSingleSource(string source)
{
  std::map<string,Vertex>::iterator it;
  for(auto it = vertices.begin(); it != vertices.end(); it++)
  {

    it->second.pi = "";
    it->second.key = INT_MAX;
  }
  vertices[source].key = 0;
}
