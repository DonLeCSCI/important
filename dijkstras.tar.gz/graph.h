#include<vector>
#include<string>
#include "minpriority.h"
#include<map>
#include<algorithm>
#ifndef GRAPH_H
#define GRAPH_H
using std::string;
using std::vector;
//using std::sort;
using std::map;
class Graph {
    private:
      MinPriorityQueue minQ;
        class Vertex {
            public:
                Vertex();
                Vertex(string pi,int key);
               ~Vertex(){};
                string pi;
                int key;
        };
        class Neighbor{
            public:
                bool operator<(const Neighbor& n) const{return name<n.name;}
                Neighbor(){};
                Neighbor(string name, int weight);
                ~Neighbor(){};
                string name;
                int weight;
        };
        string currentSource;
        map<string, Vertex> vertices;
        map<string, vector<Neighbor>> adjList;
        void buildSSPTree(string source);
        void relax(string u,string v,int weight);
        void initializeSingleSource(string source);
    public: 

        void addVertex(string name);
        void addEdge(string from,string to,int weight);
        string getShortestPath(string from,string to);
}; 

#endif
