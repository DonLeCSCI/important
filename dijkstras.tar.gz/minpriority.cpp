/*
Don Le
CSCI 311
*/
#include<vector>
#include<string>
#include "minpriority.h"
#include<iostream>
using std::string;

/* 
   @brief MinPriorityQueue class constructor
   @param - none
*/
MinPriorityQueue::MinPriorityQueue()
{


}

/*
    @brief MinPriorityQueue class destructor
    @param - none
*/
MinPriorityQueue::~MinPriorityQueue()
{
    minHeap.clear();
}

/*
   @brief Element class constructor
   @param - none 
*/
MinPriorityQueue::Element::Element()
{


}

/* 
   @brief Element class constructor
   @param - a constant string named id and an integer named key
*/
MinPriorityQueue::Element::Element(const string& id, int key)
{
    this->id = new string(id);
    this->key = key;
} 

/*
   @brief Element class destructor
   @param - none
*/
MinPriorityQueue::Element::~Element()
{
    delete id;
}

/* 
   @brief returns an integer
   @param - an integer named i
*/
int MinPriorityQueue::parent(int i)
{
    return i/2;
}

/*
   @brief returns an integer
   @param - an integer named i
*/
int MinPriorityQueue::left(int i)
{
    return (i*2);
}

/*
  @brief returns an integer
  @param - an integer named i
*/
int MinPriorityQueue::right(int i)
{
    return (i*2)+1;
}

/* 
  @brief calls minheapify functions on half the vector
  @param - none
*/
void MinPriorityQueue::buildMinHeap()
{
    for(int i=(minHeap.size()-1)/2; i > 0; i--)
    {
        minheapify(i);
    }

}

/*
 @brief check is the queue is empty
 @param - none
 
*/
bool MinPriorityQueue::empty()
{
  if(minHeap.size()!= 0)
  {
    return false;
  }
  return true;
}

/*
   @brief arranges node i and the subtrees to satisfy the heap property
   @param an integer named i
*/
void MinPriorityQueue::minheapify(int i)
{
    int l = left(i);
    int r = right(i);
    int smallest;
    if(l < (int)minHeap.size() && minHeap[l]->key < minHeap[r]->key)
        smallest = l;
    else smallest = i;
    if(r < (int)minHeap.size() && minHeap[r]->key < minHeap[smallest]->key)
        smallest = r;
    if(smallest != i)
    {
        std::swap(minHeap[i], minHeap[smallest]);
        minheapify(smallest); 
    }
}

/*
  @brief implements insert operations into a vector
  @param - a constant string named id and an integer named key 
*/
void MinPriorityQueue::insert(const string& id, int key)
{   
    Element *newElement = new Element(id,key);
    minHeap.push_back(newElement);
    decreaseKey(id,key);
    /* for(unsigned int i = 0; i < minHeap.size(); i++){
       std::cout << *minHeap[i]->id << " " << minHeap[i]->key << std::endl;
       }
     */
}

/*
   @brief helps by restoring min-heap property
   @param a string named id and an integer named key
*/
void MinPriorityQueue::decreaseKey(string id, int key)
{   
    int num = 0;
    for(int i = 0; i <(int)minHeap.size(); i++)
    {
        if(id == (*minHeap[i]->id))
        {
            if(key > minHeap[i]->key)
            {
                std::cerr << "HIGHER OLD KEY" << std::endl;
                return;
            }
            num = i;
            minHeap[i]->key = key;
            break;
        }
    }
    while(num > 0 && minHeap[parent(num)]->key > minHeap[num]->key)
    {
        std::swap(minHeap[num],minHeap[parent(num)]);
        num = parent(num);
    }
}

/*
   @brief removes minimum element from heap
   @param - none 
*/
string MinPriorityQueue::extractMin()
{
    if(minHeap.size() == 0)
    {
        return "heap underflow";
    }
    Element *newElement;
    newElement = minHeap[0];
    minHeap[0] = minHeap[minHeap.size()-1];
    minHeap.pop_back();
    minheapify(0);
    return *newElement->id;
}

