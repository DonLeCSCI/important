#include<vector>
#include<string>
using std::string;
class MinPriorityQueue{
    public:
        MinPriorityQueue();
        ~MinPriorityQueue();
        void insert(const string&, int);
        void decreaseKey(string,int);
        string extractMin();
        bool empty(); 

    private:
        void buildMinHeap();
        void minheapify  (int);
        int parent(int);
        int left(int);
        int right(int);

        class Element{
            public:
                string *id;
                int key;
                Element();
                Element(const string&, int);
                ~Element();
        };
        std::vector<Element*> minHeap;
};
