#include<string>
#include<iostream>
#include<fstream>
#include "sspapp.h"
#include <cstdlib>
using std::string;

/*
 @brief: will read in values and store them in the maps
 @param: none
*/
void SSPapp::readGraph()
{
  int numVert;
  string vertIdent;
  int numEdges;
  std::cin >> numVert;
  for(int i = 0; i < numVert; i++)
  { 
    std::cin >> vertIdent;
    myGraph.addVertex(vertIdent);

  } 
  std::cin >> numEdges;
  for(int j = 0; j < numEdges; j++)
  {
    string from;
    string to;
    int weight;
    std::cin >> from >> to >> weight;  
    myGraph.addEdge(from,to,weight);
  }
}

/*
  @brief: will take in values and proces them accordingly
  @param: none
*/
void SSPapp::processQueries()
{
  string start;
  string end;
  while(std::cin>>start)
  {
    std::cin>>end;
    if(start == "quit" || start == "Quit" || end == "quit" || end == "quit")
    {
      return;
    }
    //std::cin>>end;
    myGraph.getShortestPath(start,end);
  }
}

int main()
{
  SSPapp newSSP;
  newSSP.readGraph();
  newSSP.processQueries();
  return 0;
}
