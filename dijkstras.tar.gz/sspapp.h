#include "graph.h"
#ifndef SSPAPP_H
#define SSPAPP_H
class SSPapp{
    public:
        void readGraph();
        void processQueries();
    private:
        Graph myGraph;
};
#endif
