#include<iostream>
#include<string>
#include "party.h"

/*
@brief Party Constructor
*/
Party::Party() {
}

/*
@brief Party Constructor
@param reservationName-a string , numDiners -integer of how many diners, 
timeRequired - integer of time
*/
Party::Party(const string& reservationName, int numDiners, int timeRequired)
{
this->reservationName = new string(reservationName);
this->numDiners = numDiners;
this->timeRequired = timeRequired;
}

/*
@brief Party destructor
*/
Party::~Party()
{
delete reservationName;
}
