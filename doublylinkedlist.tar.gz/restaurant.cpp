#include <iostream>
#include <string>
#include <map>
#include "restaurant.h"
#include "party.h"
#include "table.h"
using std::string;
using std::cin;
using std::cout;
using std::endl;

/*
@brief
will take in all the input from the command line then make a new object that 
keeps in all that data and append it
*/

void Restaurant::getInput()
{
  string input = " ";
  string nameofTable;
  string nameofServer;
  string nameofReservation;
  int numofSeats;
  int numofDiners;
  int timeLeft;
  while(cin >> input)
  {
    if(input == "table")
    {
      cin >> nameofTable >> numofSeats >> nameofServer;
      available.append(new Table(nameofTable, numofSeats, nameofServer));
    }
    else if(input == "party")
    {
      cin >> numofDiners>> nameofReservation>> timeLeft;
      waiting.append(new Party(nameofReservation, numofDiners, timeLeft));
    }
    if(input == "end")
    {
      break;
    }
  }
}


/*
 * @brief
 *    Seats the parties on the waiting list into available tables in the restaurant
 *    with the correct amount of seats at the table.
 *    Once the party finishs with the table the table goes back to being available
 *    so another party can be seated.
 *
 */
void Restaurant::serveParties()
{
  bool storeOpen = true;
  while(storeOpen == true)
  {
    Table *newTable;
    newTable= occupied.first();
    while(newTable != nullptr)
    {
      bool remove = false;
      newTable -> decrementTimer();
      if(newTable -> getTimer() == 0)
      {
        cout << *(newTable->getParty()->getReservationName()) << " finished at " << *(newTable->getTableID()) << endl;
        newTable->clearTable();
        available.append(newTable);
        newTable = occupied.remove();
        remove = true;
      }
      if(remove == false)
      {
        newTable = occupied.next();
      }
    }
    Party *newParty;
    newParty = waiting.first();
    while(newParty != nullptr)
    {
      bool removedParty = false;
      Table *anotherTable;
      anotherTable = available.first();
      while(anotherTable != nullptr)
      {
	int numSeats = anotherTable->getNumSeats();
	int numDiners = newParty->getNumDiners();
	if(numSeats >= numDiners)
        {
          cout << *(newParty->getReservationName()) << " seated at " << *(anotherTable->getTableID()) << endl;
          anotherTable -> seatParty(newParty);
          anotherTable -> setTimer(newParty -> getTimeRequired());
          occupied.append(anotherTable);
	  string serverName = (*anotherTable->getServerName());
          servers[serverName] += newParty->getNumDiners();
          anotherTable = available.remove();
          newParty = waiting.remove();
          removedParty = true;
	  break;
        }
        anotherTable = available.next();
      }

      if(removedParty == false)
      {
        newParty = waiting.next();
      } 
    }
    if(waiting.empty() == true && occupied.empty() == true)
    { 
      for(auto it = servers.cbegin(); it != servers.cend(); ++it)
      {
        cout << it->first << " served " << it->second << endl;
      }
      storeOpen = false;
    }
  }
}
int main()
{
  Restaurant myDiner;
  myDiner.getInput();
  myDiner.serveParties();
}
