/* 
 Don Le
 CSCI 311
*/
#include<iostream>
#include "minpriority.h"
#include<vector>
int main()
{
    int key;
    string input, id;
    MinPriorityQueue newMin;
    std::cin>>input;
    while(1)
    {   
        if(input == "a")
        {
            std::cin>>id>>key;
            newMin.insert(id,key);
        }
        else if(input == "d")
        {
           std::cin>>id>>key;
           newMin.decreaseKey(id,key); 
        }
        else if(input == "x")
        {
           string s = newMin.extractMin();
           std::cout << s << std::endl;
        }
        else
        {
           exit(1);
        }
    std::cin>>input;
    }
return 0;
}
