#include<iostream>
#include<fstream>
#include "matrix.h"
#include "robot.h"
#include<sstream>
#include <iomanip>
using namespace std;
vector<vector<long double>> probMatrix(vector<string> vect, string val)
{
  string binary = "";
  vector<vector<long double>> prob(vect.size(),vector<long double>(vect.size(),0));
  for(int k = 0; k < vect.size(); k++)
  {
    int count = 0;
    binary = vect[k];
    for(int i = 0; i < binary.size(); i++)
    {
      if(binary[i] != val[i])
        count++;
    }
    if(count == 0)
      prob[k][k] = .6561;
    if(count == 1)
      prob[k][k] = .0729;
    if(count == 2)
      prob[k][k] = .0081;
    if(count == 3)
      prob[k][k] = .0009;
    if(count == 4)
      prob[k][k] = .0001;
  }

  for(int j = 0; j < prob.size(); j++)
  {
    for(int p = 0; p < prob[j].size(); p++)
      cout << prob[j][p] << " ";
    cout << endl;
  }
  return prob; 

}

vector<vector<long double>> transitivity(vector<string>vect, int c)
{
  double val;
  string binary = "";
  float percent; 
  int n;

  vector<vector<long double>> trans(vect.size(),vector<long double>(vect.size(),0));
  for(int i = 0; i < vect.size(); i++)
  {
    int count = 0;
    binary = vect[i];
    cout << "binary " << " " << binary << endl;
    for(int k = 0; k < binary.size(); k++)
    {
      if(binary[k] == '0')
        count ++;
      cout << "count:" << " " << count << endl;
    }

    if(count != 0)  
      percent = (float)1/count;
    if(binary[0] == '0') // s
    {     
      cout << vect.size()/c << endl;
      n = i - ((vect.size()/c));
      trans[n][i] = percent;
    }  
    if(binary[1] == '0') //n
    {
      n = i + ((vect.size()/c));
      trans[n][i] = percent;
    }
    if(binary[2] == '0') //w
    {
      n = i - 1;
      trans[n][i] = percent;
    }
    if(binary[3] == '0') //e
    {
      n = i + 1;
      trans[n][i] = percent;

    }
  }
  for(int j = 0; j < trans.size(); j++)
  {
    for(int p = 0; p < trans[j].size(); p++)
      cout << trans[j][p] << " ";
    cout << endl;
  }
  return trans;
}


string toBinary(int n)
{
  if( n == 0)
    return "0000";
  string val = "";
  while(n>0)
  {
    val = ((n & 1) == 0? '0' : '1') + val;
    n /=2;
  }
  while(val.size() < 4)
  {
    val = '0' + val;
  }
  return val;
}

string toBinary2(string n)
{
  cout << n << endl;
  string binary = "0000";
  for(int i = 0; i < n.size(); i++)
  {
    if(n[i] == 'N')
      binary[0] = '1';
    else if(n[i] == 'S')
      binary[1] = '1';
    else if(n[i] == 'W')
      binary[2] = '1';
    else if(n[i] == 'E')
      binary[3] = '1';
  }
  cout << binary << endl;
  return binary;
}



int main( int argc, char* argv[])
{
  string input1 = argv[1];
  float sens = atof(argv[2]);

  vector<int> theVec;
  vector<string> binaryVal; 
  ifstream myReadFile; 
  myReadFile.open(input1); 
  string line; 
  int val;
  int num;
  int c = 0;
  string binary = "";
  while(getline(myReadFile,line))
  {
    c++;
    istringstream str(line);
    while(str >> val)
    {
      theVec.push_back(val);
    }
  }

  for(int i = 0; i < theVec.size(); i++)
  {
    num = theVec[i];
    binary = toBinary(num);
    binaryVal.push_back(binary);
  }
  vector<long double> info;
  vector<vector<long double>> theT = transitivity(binaryVal,c);

  int divi = 0;
  for( int t = 0;t < theT.size(); t++)
  {
    for( int p = 0;  p < theT[t].size(); p++)
    {
      if(theT[t][p] !=0)
      {
        divi++;
        break;
      }
    }
  }

  long double tval;
  

  long double numba = (1.0/divi) ;
  for(int k = 0; k < theVec.size(); k++)
  {
    info.push_back(numba);
  }
  Matrix m;
  Robot r;

  vector<long double> jointOne = m.joint(theT, info);
  string seq = argv[3];
  string uno = toBinary2(seq);
  vector<vector<long double>> theProb = probMatrix(binaryVal, uno);
  vector<long double> SUMyOne = m.joint(theProb, jointOne);
  long double valyONE = 0;
    for(int i = 0; i <  SUMyOne.size(); i++)
    {
      valyONE += SUMyOne[i];
    }
    vector<long double> estimation;

    for(int p = 0; p < SUMyOne.size(); p++)
    {
      long double y = SUMyOne[p];
      long double k = r.estimationProb(valyONE, y);
      estimation.push_back(k);
    }

    long double max = estimation[0];
    int state;
    for(int t = 1; t < estimation.size(); t++)
    {
      if(estimation[t] > max)
      {
        max = estimation[t];
      }
    }
     

   cout << std::showpoint << std::fixed << setprecision(12) << max;

    for(int i = 0; i < estimation.size(); i++)
    {

      if(max == estimation[i])
      {
        state = i;
        cout << " " << state;
      }
    }
    cout << endl;

  vector<long double> tim = m.joint(theT, SUMyOne);

 int count = 4 ;
  while(count < argc)
  {
    string seq1 = argv[count];
    count ++;
    string one = toBinary2(seq1);
    vector<vector<long double>> theProb = probMatrix(binaryVal, one);
    vector<long double> cc = m.joint(theProb,tim);
     double valyONE = 0;
     tim.clear();

    for(int i = 0; i < cc.size(); i++)
    {
      tim.push_back(cc[i]);
      valyONE += cc[i];
    }

    vector<long double> estimation;
    for(int p = 0; p < tim.size(); p++)
    {
      long double y = tim[p];
      long double k = r.estimationProb(valyONE, y);
      estimation.push_back(k);
    }
    max = estimation[0];
    int state;
    for(int t = 1; t < estimation.size(); t++)
    {
      if(estimation[t] > max)
      {
        max = estimation[t];
      }
    }
     
   cout << std::showpoint << std::fixed << setprecision(12) << max;

    for(int i = 0; i < estimation.size(); i++)
    {
      if(max == estimation[i])
      {
        state = i;
        cout << " " << state;
      }
    }
    cout << endl;
  }


  return 0;
} 
