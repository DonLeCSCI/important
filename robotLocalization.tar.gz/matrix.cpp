#include<iostream>
#include<fstream>
#include "matrix.h"
#include<string>
#include <iomanip>
using namespace std;

//given matrix and vector will go through and calculate joint probs
vector<long double> Matrix::joint(vector<vector<long double>> &transit, vector<long double> &p)
{
  vector<long double> jProb;

  for(int i = 0; i < transit.size(); i++)
  {
    long double val = 0;
    for(int j = 0; j < transit[i].size(); j++)
    {
        val = val + ((long double)p[j] * (long double)transit[i][j]);
    }
    jProb.push_back(val);
  }
  for(int p = 0; p < jProb.size();p++)
  {
    cout << jProb[p] << endl;
  }
  cout << endl;
  return jProb;
}



