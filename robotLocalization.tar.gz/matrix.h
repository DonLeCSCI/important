
#ifndef MATRIX_H
#define MATRIX_H
#include<cstdlib>
#include <vector>
using namespace std;



class Matrix{
  public:
    vector<long double> joint(vector<vector<long double>> &transit, vector<long double> &p);

};
#endif
