#include<iostream>
#include "robot.h"
using namespace std;

long double Robot::estimationProb(long double sum, long double yOne)
{
  long double val;
  val = (1/sum) * yOne;
  return val;
}
