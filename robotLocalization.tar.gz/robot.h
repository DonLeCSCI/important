#ifndef ROBOT_H
#define ROBOT_H
#include<cstdlib>
#include <vector>
using namespace std;

class Robot{
  public:
    long double estimationProb(long double sum, long double yOne);
};
#endif
