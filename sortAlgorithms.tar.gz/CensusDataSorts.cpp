/**
 * @file CensusDataSorts.cpp   Sort functions for census population data.
 * 
 * @brief
 *    Implements several different types of sorts. Data can be sorted
 * by population or by name of town. This file contains all of the sorting
 * functions and their helpers.
 *
 * @author Judy Challinger
 * @date 2/22/13

sources :http://www.cplusplus.com/reference/random/uniform_int_distribution/operator()/
*/

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include "CensusData.h"
#include <climits>
#include <random>
#include <chrono>
/*
@brief insert in order algorithm by iteration
@param type - a number for type; either population or city name
*/
// formal parameter name commented out to avoid unused variable warning
void CensusData::insertionSort(int type) {
  int size = getSize();
  if(type == 0){
    for ( int j = 1; j < size; j++)
    {
      Record * key = data[j];
      int i = j - 1;
      while(i>=0 &&  data[i]->population > key->population){
        data[i+1] = data[i]; 
        i=i-1;
      }
      data[i+1]= key; // maybe key
    }
  }
  else {
    for(int j = 1; j < size; j++){
      Record *key = data[j];
      int i = j - 1;
      while(i >= 0 && (*data[i]->city) > *(key->city)){
        data[i+1] = data[i];
        i-=1;
      }
      data[i+1] = key;
    }
  }
}
/*
@brief algorithm to insert in order recursively
@param - a number for type; either population or city name
*/
void CensusData::mergeSort(int type){
  int size = getSize() - 1;
  if(type == 0){
    merge(type,0,size);
  }
  else{
    merge(type,0,size);
  }
}

/* @brief helper recursive function that calls itself and actual merge function
@param - a number for type; either population or city name, p - int for divided array, r - int for divided array
*/
// formal parameter name commented out to avoid unused variable warning
void CensusData::merge(int type,int p, int r) { 
  if(p<r)
  {
    int q = ((p+r)/2);
    merge(type,p,q);
    merge(type,q+1,r);
    merge_A(type,p,q,r);
  }
  //copy pseudo code
} 
/* @brief actual merge function that push data in and organized
@param a number for type; either population or city name, p - int
, r - int
*/
void CensusData::merge_A(int type, int p, int q, int r){ 
  if(type == 0){ 	
    int numOne = q - p + 1; 
    int numTwo = r - q; 
    vector<Record*> L;
    vector<Record*> R;
    for(int i = 0; i < numOne; i++){
      L.push_back(data[p+i]); //push
    }
    for(int j = 0; j < numTwo; j++){
      R.push_back(data[q+j+1]);
    }
    string bigString = "zzzzzzzzzzz";
    Record *numbers = new Record(bigString,bigString, INT_MAX);
    L.push_back(numbers);
    R.push_back(numbers);
    int i = 0;
    int j = 0;
    for(int k=p; k<=r; k++){
      if(L[i]->population <= R[j]->population){
        data[k] = L[i];
        i += 1;
      }
      else{
        data[k] = R[j];
        j+=1;
      }
    }
  }
  else{   // for type = cityName
    int numOne = q - p + 1;
    int numTwo = r - q;
    vector<Record*> L;
    vector<Record*> R;
    for(int i = 0;i< numOne; i++){
      L.push_back(data[p+i]);
    }
    for(int j = 0; j< numTwo;j++){
      R.push_back(data[q+j+1]);
    }
    string bigString = "zzzzzzzzzzz";
    Record *numbers = new Record(bigString,bigString, INT_MAX);
    L.push_back(numbers);
    R.push_back(numbers);
    int i = 0;
    int j = 0;
    for(int k = p; k <= r; k++){
      if(*(L[i]->city) <= *(R[j]->city)){
        data[k] = L[i];
        i+=1;
      }else{
        data[k] = R[j];
        j+=1;
      }
    }
  }
} 
/*
@brief this function splits up the array
@param number for type; either population or city, p-int, r -int
*/
int CensusData::partition(int type, int p, int r){
  if(type == 0){
    Record *newPtr = data[r];
    int i = p - 1;
    for(int j = p; j < r; j++){
      if(data[j]->population <= newPtr->population){
        i+=1;
        std::swap(data[i],data[j]);
        //data[i] = data[j];
      }	
    }
    //data[i+1] = newPtr;
    std::swap(data[i+1],data[r]);
    return i+1;
  }
  else{
    Record *newPtr = data[r];
    int i = p - 1;
    for(int j = p; j < r; j++){
      if((*data[j]->city) <= (*newPtr->city)){
        i+=1;
        //data[i] = data[j];
        std::swap(data[i],data[j]);
      }
    }
    std::swap(data[i+1],data[r]);
    return i+1;
  }
  return 0;
}
/* @brief quick sort help function 
@param number for type; either population or city
*/
void CensusData::quickSort(int type){
  int size = getSize()-1;
  helpQuick_Sort(type,0,size);
}
/* @brief quick sort helper function that calls random partitoning
@param number for type; either population or city, p- int
r-int)
*/
void CensusData::helpQuick_Sort(int type, int p, int r) {
  if(p < r){
    int q = rando_partition(type,p,r);
    helpQuick_Sort(type,p,q-1);
    helpQuick_Sort(type,q+1,r);
  }
}
/* @brief partitions and places array randomly in order
@param number for type;either population or city, p- int, r-int
*/
int CensusData::rando_partition(int type, int p, int r){
  unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
  std::default_random_engine generator (seed);
  std::uniform_int_distribution<int> distribution(p,r);
  unsigned int t = distribution(generator);
  Record * ptr = data[r];
  data[r] = data[t];
  data[t] = ptr;
  //  std::swap(data[r],data[t]);
  return partition(type,p,r);
}
/*
   int CensusData::Randomize(int p,int r){
   unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
   std::default_random_engine generator (seed);
   std::uniform_int_distribution<int> distribution(p,r);
   return distribution(generator);
   }
   */
